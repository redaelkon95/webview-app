# تطبيق عرض الموقع (WebView)

## بناء الـ APK بدون Android Studio (GitHub Actions)
1. اعمل Repository جديد على GitHub وارفع كل محتوى المجلد (لازم مجلد .github يترفع).
2. من تبويب Actions شغّل "Build APK" (Run workflow).
3. بعد ما يخلص (3-5 دقايق) نزّل app-apk من Artifacts، فك الضغط وثبّت app-release.apk.

## أو بـ Android Studio
File > Open > اختار المجلد > Build > Build APK(s).
