package com.mysite.webapp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun name(c: Context): String =
        sp(c).getString("name", null)?.takeIf { it.isNotBlank() } ?: c.getString(R.string.app_name)

    fun url(c: Context): String = sp(c).getString("url", "") ?: ""
    fun showGear(c: Context): Boolean = sp(c).getBoolean("gear", true)

    fun save(c: Context, name: String, url: String, gear: Boolean) {
        sp(c).edit().putString("name", name.trim()).putString("url", normalizeUrl(url)).putBoolean("gear", gear).apply()
    }

    fun logoFile(c: Context) = File(c.filesDir, "logo.png")
    fun logo(c: Context): Bitmap? = logoFile(c).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun normalizeUrl(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return ""
        return if (t.startsWith("http://", true) || t.startsWith("https://", true)) t else "https://$t"
    }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
