package com.mysite.webapp

import android.Manifest
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var splash: LinearLayout
    private lateinit var splashLogo: ImageView
    private lateinit var splashName: TextView
    private lateinit var gear: ImageButton

    private var loadedUrl: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var permRequest: PermissionRequest? = null
    private var geoCb: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCallback = null
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        permRequest?.let { if (res.values.all { ok -> ok }) it.grant(it.resources) else it.deny() }
        permRequest = null
    }
    private val geoLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        geoCb?.invoke(geoOrigin, ok, false)
        geoCb = null
    }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = FrameLayout(this)
        web = WebView(this)
        configureWebView()
        swipe = SwipeRefreshLayout(this).apply {
            addView(web, ViewGroup.LayoutParams(MATCH, MATCH))
            setOnRefreshListener { web.reload() }
            setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        }
        root.addView(swipe, FrameLayout.LayoutParams(MATCH, MATCH))

        splash = buildSplash()
        root.addView(splash, FrameLayout.LayoutParams(MATCH, MATCH))

        gear = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_preferences)
            setBackgroundColor(Color.TRANSPARENT)
            alpha = 0.4f
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        root.addView(gear, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(8), dp(8), dp(8), dp(8))
        })
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreen()
                    web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })

        if (savedInstanceState == null && Prefs.url(this).isBlank()) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        val url = Prefs.normalizeUrl(Prefs.url(this))
        val logo = Prefs.logo(this)
        if (logo != null) splashLogo.setImageBitmap(logo) else splashLogo.setImageResource(R.drawable.ic_launcher)
        splashName.text = Prefs.name(this)
        gear.visibility = if (Prefs.showGear(this) || url.isBlank()) View.VISIBLE else View.GONE
        if (url.isBlank()) {
            splash.visibility = View.VISIBLE
            Toast.makeText(this, "أضف رابط الموقع من الإعدادات", Toast.LENGTH_LONG).show()
            return
        }
        if (url != loadedUrl) {
            loadedUrl = url
            splash.visibility = View.VISIBLE
            web.loadUrl(url)
        }
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        root.removeAllViews()
        web.destroy()
        super.onDestroy()
    }

    private fun buildSplash(): LinearLayout {
        splashLogo = ImageView(this)
        splashName = TextView(this).apply {
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#222222"))
            gravity = Gravity.CENTER
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            isClickable = true
            addView(splashLogo, LinearLayout.LayoutParams(dp(120), dp(120)))
            addView(splashName, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(16) })
            addView(ProgressBar(this@MainActivity), LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(24) })
        }
    }

    private fun configureWebView() {
        with(web.settings) {
            javaScriptEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            setGeolocationEnabled(true)
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.setDownloadListener { url, ua, cd, mime, _ ->
            try {
                val req = DownloadManager.Request(Uri.parse(url))
                req.setMimeType(mime)
                req.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                req.addRequestHeader("User-Agent", ua)
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "بدأ التحميل...", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val s = u.scheme ?: ""
                if (s == "http" || s == "https") return false
                try {
                    if (s == "intent") startActivity(Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME))
                    else startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (_: Exception) {}
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                swipe.isRefreshing = false
                splash.visibility = View.GONE
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress >= 60) splash.visibility = View.GONE
            }

            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                return try { filePicker.launch(p.createIntent()); true } catch (e: Exception) { fileCallback = null; false }
            }

            override fun onPermissionRequest(req: PermissionRequest) {
                runOnUiThread {
                    val needed = mutableListOf<String>()
                    req.resources.forEach {
                        if (it == PermissionRequest.RESOURCE_VIDEO_CAPTURE) needed += Manifest.permission.CAMERA
                        if (it == PermissionRequest.RESOURCE_AUDIO_CAPTURE) needed += Manifest.permission.RECORD_AUDIO
                    }
                    val missing = needed.filter {
                        ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                    }
                    if (missing.isEmpty()) req.grant(req.resources)
                    else { permRequest = req; permLauncher.launch(missing.toTypedArray()) }
                }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                val ok = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
                if (ok) callback.invoke(origin, true, false)
                else { geoOrigin = origin; geoCb = callback; geoLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
            }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view
                customCb = cb
                swipe.visibility = View.GONE
                root.addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    hide(WindowInsetsCompat.Type.systemBars())
                }
            }

            override fun onHideCustomView() = exitFullscreen()
        }
    }

    private fun exitFullscreen() {
        customView?.let { root.removeView(it) }
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        swipe.visibility = View.VISIBLE
        WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }
}
