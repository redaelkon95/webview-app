package com.mysite.webapp

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import java.io.FileOutputStream

class SettingsActivity : AppCompatActivity() {
    private lateinit var preview: ImageView

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveLogo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 14f; setPadding(0, dp(16), 0, dp(4))
        }
        val full = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        col.addView(TextView(this).apply {
            text = "إعدادات التطبيق"; textSize = 22f; setTypeface(null, Typeface.BOLD)
        })

        preview = ImageView(this)
        col.addView(preview, LinearLayout.LayoutParams(dp(96), dp(96)).apply { topMargin = dp(16) })
        showLogo()
        col.addView(Button(this).apply {
            text = "اختيار الشعار"
            setOnClickListener { pick.launch("image/*") }
        })

        col.addView(label("اسم التطبيق"))
        val name = EditText(this).apply {
            setText(Prefs.name(this@SettingsActivity)); setSingleLine()
        }
        col.addView(name)

        col.addView(label("رابط الموقع"))
        val url = EditText(this).apply {
            setText(Prefs.url(this@SettingsActivity))
            hint = "https://example.com"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        col.addView(url)

        val gear = SwitchCompat(this).apply {
            text = "إظهار زر الإعدادات داخل التطبيق"
            isChecked = Prefs.showGear(this@SettingsActivity)
        }
        col.addView(gear, LinearLayout.LayoutParams(full, wrap).apply { topMargin = dp(16) })
        col.addView(TextView(this).apply {
            text = "لو أخفيته: اضغط مطولاً على أيقونة التطبيق واختر «الإعدادات»."
            textSize = 12f
        })

        col.addView(Button(this).apply {
            text = "حفظ"
            setOnClickListener {
                Prefs.save(this@SettingsActivity, name.text.toString(), url.text.toString(), gear.isChecked)
                Toast.makeText(this@SettingsActivity, "تم الحفظ", Toast.LENGTH_SHORT).show()
                finish()
            }
        }, LinearLayout.LayoutParams(full, wrap).apply { topMargin = dp(24) })

        col.addView(Button(this).apply {
            text = "إضافة اختصار بالاسم والشعار للشاشة الرئيسية"
            setOnClickListener {
                Prefs.save(this@SettingsActivity, name.text.toString(), url.text.toString(), gear.isChecked)
                pinShortcut(Prefs.name(this@SettingsActivity))
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun showLogo() {
        val b = Prefs.logo(this)
        if (b != null) preview.setImageBitmap(b) else preview.setImageResource(R.drawable.ic_launcher)
    }

    private fun saveLogo(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1024) sample *= 2
            val bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return
            val ratio = minOf(1f, 512f / maxOf(bmp.width, bmp.height))
            val out = if (ratio < 1f)
                Bitmap.createScaledBitmap(bmp, (bmp.width * ratio).toInt().coerceAtLeast(1), (bmp.height * ratio).toInt().coerceAtLeast(1), true)
            else bmp
            FileOutputStream(Prefs.logoFile(this)).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            preview.setImageBitmap(out)
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر تحميل الصورة", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pinShortcut(label: String) {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            Toast.makeText(this, "الـ Launcher مش بيدعم إضافة اختصارات", Toast.LENGTH_LONG).show()
            return
        }
        val bmp = Prefs.logo(this)
        val icon = if (bmp != null) IconCompat.createWithBitmap(bmp) else IconCompat.createWithResource(this, R.drawable.ic_launcher)
        val intent = Intent(this, MainActivity::class.java).setAction(Intent.ACTION_MAIN)
        val info = ShortcutInfoCompat.Builder(this, "site_" + System.currentTimeMillis())
            .setShortLabel(label).setLongLabel(label).setIcon(icon).setIntent(intent).build()
        ShortcutManagerCompat.requestPinShortcut(this, info, null)
    }
}
